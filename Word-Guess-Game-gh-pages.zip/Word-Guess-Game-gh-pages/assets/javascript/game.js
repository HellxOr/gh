﻿
// variable lists:
var letter = 0;
var userGuessedLetters = "";
var userInput;
var word = "";
var vocabularyList = ["Apple","Banana","Pamelo","Pineapple","Kiwi","Tomato"]
var scores = 0;
var blanks = []
var randomInt = 0;
var guessRemainingCount = 10;
var isFinished = false;


 // Create variables that hold references to the places in the HTML where we want to display things.
var wordBlanks = document.getElementById("word-played");
var remainingGuess = document.getElementById("guess-remaining-count")
var winScores = document.getElementById("wins-score")
var letterGuessed = document.getElementById("letters-guessed")

// Use underscore "_" to represent the how many letters in the words to be guessed

function unknownWords()
 {
     for (var i = 0; i < word.length; i++)
    {
        blanks.push("_");
     }
    
    wordBlanks.textContent = blanks;
 }

// Randomly generates a word using an array of vocabularyList
function computerGeneratedWord (vocabularyList)
{
    randomInt = Math.floor(Math.random() * vocabularyList.length);
    word = vocabularyList[randomInt];
    word = word.toLowerCase();
    console.log(word)
}

// Compare the user input to the word to be gusses, if the user guessed correct,
// it replaces the "_" with the letter and displays the remaining guess count.
function compareUserInputToWord(letter)
{
    if (word.includes(letter) && isFinished === false)
    {
        for (var i = 0; i < word.length; i++)
        {
            if (word.charAt(i) === letter)
            {
                blanks[i] = letter;
            }
        }
        wordBlanks.textContent = blanks;
        remainingGuess.textContent = guessRemainingCount;
    }
    else if (userGuessedLetters.includes(letter)) {
        return;
    }
    else if (guessRemainingCount !== 0 && isFinished !== true) {
        guessRemainingCount--;
        remainingGuess.textContent = guessRemainingCount;
        userGuessedLetters = userGuessedLetters + " " + letter;
        letterGuessed.textContent = userGuessedLetters;
    }
    else
    {
        alert("Game over, please refresh page to try again")
        isFinished = true
        return;
    }
}

// Check and see if an user successfully guessed all the letters and display
// the win counts
function scoreKeeping()
{
    if (!blanks.includes("_") && isFinished === false) {
        scores++;
        winScores.textContent = scores;
        alert("Congraduation you have guessed the correct word, PLease refresh the page to continue")
        isFinished = true
        return;
    }
    else
    {
        winScores.textContent = scores;
    }
}

//main function starts the game
function main()
{
    if (guessRemainingCount !== 0)
    {
        computerGeneratedWord(vocabularyList);
        unknownWords();
        document.onkeyup = function (event)
        {
            userInput = event.key;
            compareUserInputToWord(userInput);
            scoreKeeping();
            return;                
        };
    }
    else if (isFinished === true)
    {
        return;
    }

}

main();